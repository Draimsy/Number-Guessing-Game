from tkinter import *
import random
from tkinter import messagebox

#: Creating the window
window = Tk()
window.title("Guessing game")
window.geometry("1300x1100")

#: Window Icon
icon = PhotoImage(file='icon3.png')
window.iconphoto(True, icon)

#: Defining background image
bg1 = PhotoImage(file="snowman1.png")
bg2 = PhotoImage(file="guess8.png")


#: Main Page
def whole_game():
    main_frame = Frame(window, width=1300, height=1100)
    main_frame.pack(expand=True, fill="both")

#: Creating a Canvas inside the main_frame
    canvas1 = Canvas(main_frame, width=1300, height=1100,)
    canvas1.pack(expand=True, fill="both")
    canvas1.create_image(0, 0, image=bg1, anchor="nw")

#: Adding a welcome text in canvas
    canvas1.create_text(200, 200, text="Hello! \n Let's play a guessing game",
                        font=("Jokerman", 50), fill="#1b47f5", anchor="nw")

#: Opening the game frame
    def open():
        game_frame = Frame(window, width=1300, height=1100)
        game_frame.place(x=0, y=0)

#: Canvas_2 inside the game frame
        canvas2 = Canvas(game_frame, width=1300, height=1100, )
        canvas2.pack(expand=True, fill="both")
        canvas2.create_image(0, 0, image=bg2, anchor="nw")

#: Quit button in canvas 2
        quit_btn = Button(canvas2, text="QUIT", width=10, height=3, fg="Yellow", bg="purple",
                      font=("chiller", 18, "bold"), command=window.destroy)
        quit_button_window = canvas2.create_window(100, 500, anchor="nw", window=quit_btn)

#: Adding a label in canvas 2
        my_label2 = canvas2.create_text(200, 60, text="Guess any number from 1 to 100", fill="yellow",
                                        font=("Jokerman", 45), anchor="nw")

#: Input/Output boxes in canvas 2
        user_entry = Entry(game_frame, font=("chiller", 13), width=15, fg="black", bd=0)
        comp_entry = Entry(game_frame, font=("chiller", 20), width=15, fg="black", bd=0)

        user_window = canvas2.create_window(400, 200, anchor="nw", window=user_entry)
        comp_window = canvas2.create_window(400, 400, anchor="nw", window=comp_entry)
        user_entry.insert(0, "Place your guess here   ")

#: Binding the entry box
        def entry_clear(e):
            user_entry.delete(0, END)

        user_entry.bind("<Button-1>", entry_clear)

        #: Randomize Button in canvas 2
        def value_random():
            value = random.randint(1, 3)
            comp_entry.delete(0, "end")
            comp_entry.insert(0, str(value))

            entered_number = int(user_entry.get())

            def reset_boxes():
                comp_entry.delete(0, "end")
                user_entry.delete(0, "end")

            if entered_number == value:
                messagebox.showinfo("Player1", "You win, Good guess")
                reset_boxes()
            else:
                messagebox.showinfo("Fail", "Wrong Guess, try again")

        generate = Button(game_frame, text="Randomize number", width=18, font="Roman", command=value_random)
        generate_window = canvas2.create_window(600, 300, anchor="nw", window=generate)

#: Adding buttons into the main page

    #: Play button
    play_btn = Button(main_frame, text="PLAY", width=10, height=3, fg="Yellow", bg="purple",
                      font=("chiller", 18, "bold"),
                      command=open)
    play_button_window = canvas1.create_window(100, 500, anchor="nw", window=play_btn)

    #: Exit button
    def exit():
        window.destroy()

    exit_btn = Button(window, text="EXIT", width=10, height=3, fg="Yellow", bg="purple", font=("chiller", 18, "bold"),
                      command=exit)
    button2_window = canvas1.create_window(300, 500, anchor="nw", window=exit_btn)


whole_game()

window.mainloop()

